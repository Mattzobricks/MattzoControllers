#pragma once

struct MCLoggingSerialConfiguration
{
public:
    bool Enabled;    
};