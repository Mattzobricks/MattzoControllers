# Install project dependencies
The MTC4BT project currently requires these libraries:
- knolleary/PubSubClient@^2.8
- h2zero/NimBLE-Arduino@^1.2.0
- bblanchon/ArduinoJson@^6.17.3
- arcao/Syslog@^2.0.0

Furtunately you can easily install them through PlatformIO.